package com.psd2.studyproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
